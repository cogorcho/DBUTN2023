create database dbutn
GO
