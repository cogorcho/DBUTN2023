--------------------------------------------
----- Creacion de la Tabla Orientacion
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Orientacion (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_orientacion_nombre
on Orientacion(nombre);

--------------------------------------------
