--------------------------------------------
----- Creacion de la Tabla InstitucionOrientacion
----- Orden de la Tabla 002
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table InstitucionOrientacion (
	id integer primary key IDENTITY(1,1),
	institucionid integer not null,
	orientacionid integer not null,
	foreign key (institucionid)
	references Institucion(id),
	foreign key (orientacionid)
	references Orientacion(id));

create unique index uix_institucion_orientacion
on InstitucionOrientacion(institucionid, orientacionid);

--------------------------------------------
