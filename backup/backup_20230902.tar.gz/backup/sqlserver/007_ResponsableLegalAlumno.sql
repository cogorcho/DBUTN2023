--------------------------------------------
----- Creacion de la Tabla ResponsableLegalAlumno
----- Orden de la Tabla 007
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table ResponsableLegalAlumno (
    id integer primary key IDENTITY(1,1),
    ResponsableLegalid integer not null,
    alumnoid integer not null,
    foreign key (ResponsableLegalid)
    references ResponsableLegal(id),
    foreign key (alumnoid)
    references Alumno(id));

create unique index uix_resp_alumno
on ResponsableLegalAlumno(ResponsableLegalid, alumnoid);
--------------------------------------------
