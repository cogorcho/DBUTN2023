--------------------------------------------
----- Creacion de la Tabla MateriasPlan
----- Orden de la Tabla 004
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table MateriasPlan (
	id integer primary key IDENTITY(1,1),
	planestudiosid integer not null,
	materiaid integer not null,
	horassemanales integer,
	foreign key (planestudiosid)
	references PlanEstudios(id),
	foreign key (materiaid)
	references Materia(id));

create unique index uix_MateriasPlan 
on MateriasPlan(planestudiosid, materiaid);

--------------------------------------------
