--------------------------------------------
----- Creacion de la Tabla Comision
----- Orden de la Tabla 005
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Comision (
	id integer primary key IDENTITY(1,1),
	cursoid integer not null,
	nombre varchar(1024) not null,
	periodoanual integer not null,
	foreign key (cursoid)
	references Curso(id));

create unique index uix_comision_curso
on Comision(cursoid, periodoanual);

--------------------------------------------
