--------------------------------------------
----- Creacion de la Tabla HorasTurno
----- Orden de la Tabla 007
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table HorasTurno (
	id integer primary key IDENTITY(1,1),
	turnoid integer not null,
	horainicio datetime check(strftime('%H:%M', horainicio) < strftime('%H:%M', horafin)),
	horafin datetime check(strftime('%H:%M', horafin) > strftime('%H:%M', horainicio)));

create unique index uix_horas_turno 
on HorasTurno(turnoid, strftime('%H:%M', horainicio), strftime('%H:%M', horafin));

--------------------------------------------
