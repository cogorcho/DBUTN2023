--------------------------------------------
----- Creacion de la Tabla Materia
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Materia (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_materia_nombre
on Materia(nombre);

--------------------------------------------
