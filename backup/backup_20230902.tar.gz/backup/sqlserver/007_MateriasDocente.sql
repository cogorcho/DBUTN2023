--------------------------------------------
----- Creacion de la Tabla MateriasDocente
----- Orden de la Tabla 007
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table MateriasDocente (
	id integer primary key not null,
	docenteid integer not null,
	materiaid integer not null,
	foreign key (docenteid)
	references Docente(id),
	foreign key (materiaid)
	references Materia(id));

create unique index uix_materia_docente
on MateriasDocente(docenteid,materiaid);

--------------------------------------------
