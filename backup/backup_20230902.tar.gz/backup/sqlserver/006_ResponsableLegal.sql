--------------------------------------------
----- Creacion de la Tabla ResponsableLegal
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table ResponsableLegal  (
	id integer primary key IDENTITY(1,1),
	personaid integer not null,
	fingreso date not null,
	fegreso date,
	foreign key (personaid)
	references Persona(id));

--------------------------------------------
