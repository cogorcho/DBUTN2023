--------------------------------------------
----- Creacion de la Tabla AutoridadParental
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table AutoridadParental (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_relacion_parental
on AutoridadParental(nombre);

-- Madre, Padre, Tutor, Encargado

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Institucion
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Institucion (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null,
	diegrep varchar(512));

create unique index uix_institucion_nombre
on Institucion(nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Materia
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Materia (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_materia_nombre
on Materia(nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Nivel
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Nivel (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_nivel_nombre
on Nivel(nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Orientacion
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Orientacion (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_orientacion_nombre
on Orientacion(nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Pais
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Pais (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_pais
on Pais(nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla TipoDocumento
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table TipoDocumento (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null);

create unique index uix_tipodocumento_nombre
on TipoDocumento(nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla InstitucionOrientacion
----- Orden de la Tabla 002
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table InstitucionOrientacion (
	id integer primary key IDENTITY(1,1),
	institucionid integer not null,
	orientacionid integer not null,
	foreign key (institucionid)
	references Institucion(id),
	foreign key (orientacionid)
	references Orientacion(id));

create unique index uix_institucion_orientacion
on InstitucionOrientacion(institucionid, orientacionid);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Provincia
----- Orden de la Tabla 002
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Provincia (
	id integer primary key IDENTITY(1,1),
	paisid integer not null,
	nombre varchar(1024) null,
	foreign key (paisid)
	references Pais(id));	

create unique index uix_pais_provincia_nombre
on Provincia(paisid,nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Localidad
----- Orden de la Tabla 003
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Localidad (
	id integer primary key IDENTITY(1,1),
	provinciaid integer not null,
	nombre varchar(1024) null,
	foreign key (provinciaid)
	references Provincia(id));	

create unique index uix_Localidad_Provincia_nombre
on Localidad(provinciaid,nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla PlanEstudios
----- Orden de la Tabla 003
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table PlanEstudios(
	id integer primary key IDENTITY(1,1),
	InstitucionOrientacionId integer not null,
	nombre varchar(1024) not null,
	fechainicio date,
	fechafin date,
	foreign key (InstitucionOrientacionId)
	references InstitucionOrientacion(id));

create unique index uix_PlanEstudios_InstOrient_nombre
on PlanEstudios(InstitucionOrientacionId,nombre);


--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Curso
----- Orden de la Tabla 004
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
-- de cada plan-nivel(1rio, 2rio etc)
-- aca va 1er año, 2do grado, etc etc
create table Curso (
	id integer primary key IDENTITY(1,1),
	planestudioid integer not null,
	nivelid integer not null,
	nombre varchar(1024) not null,
	foreign key (planestudioid)
	references PlanEstudios(id),
	foreign key (nivelid)
	references Nivel(id));

create unique index uix_curso_plan_nivel
on Curso(planestudioid,nivelid);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Domicilio
----- Orden de la Tabla 004
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Domicilio (
	id integer primary key IDENTITY(1,1),
	localidadid integer not null,
	direccion varchar(2048) not null,
	codpos varchar(32),
	foreign key (localidadid)
	references Localidad(id));

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla MateriasPlan
----- Orden de la Tabla 004
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table MateriasPlan (
	id integer primary key IDENTITY(1,1),
	planestudiosid integer not null,
	materiaid integer not null,
	horassemanales integer,
	foreign key (planestudiosid)
	references PlanEstudios(id),
	foreign key (materiaid)
	references Materia(id));

create unique index uix_MateriasPlan 
on MateriasPlan(planestudiosid, materiaid);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Comision
----- Orden de la Tabla 005
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Comision (
	id integer primary key IDENTITY(1,1),
	cursoid integer not null,
	nombre varchar(1024) not null,
	periodoanual integer not null,
	foreign key (cursoid)
	references Curso(id));

create unique index uix_comision_curso
on Comision(cursoid, periodoanual);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Persona
----- Orden de la Tabla 005
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Persona (
    id integer identity(1,1) primary key,
    nombre varchar(128) not null,
    apellido varchar(128) not null,
    tipodocumentoid integer not null,
    documento varchar(32) not null,
    fnacto datetime not null check (fnacto < Date()),
    genero char(1) not null check (genero in ('F','M','O')),
    domicilioid integer,
    foreign key (tipodocumentoid)
    references TipoDocumento(id),
    foreign key (domicilioid)
    references Domicilio(id));

create index ix_persona_apellido_nombre
on Persona(apellido,nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Sede
----- Orden de la Tabla 005
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Sede (
	id integer primary key IDENTITY(1,1),
	institucionid integer not null,
	nombre varchar(1024) null,
	domicilioid integer not null,
	foreign key (domicilioid)
	references Domicilio(id),
	foreign key (institucionid)
	references Institucion(id));	

create unique index uix_sede_institucion_nombre
on Sede(institucionid,nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla AlumnosComision
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table AlumnosComision (
	id integer primary key IDENTITY(1,1),
	comisionid integer not null,
	alumnoid integer not null,
	foreign key (comisionid)
	references Comision(id),
	foreign key (alumnoid)
	references Alumno(id));

create unique index uix_alumnos_comision
on AlumnosComision(comisionid, alumnoid);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Alumno
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Alumno  (
	id integer primary key IDENTITY(1,1),
	institucionid integer not null,
	personaid integer not null,
	fingreso date not null,
	fegreso date,
	foreign key (institucionid)
	references Institucion(id),
	foreign key (personaid)
	references Persona(id));

create unique index uix_alumno
on Alumno(institucionid,personaid);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Aula
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Aula(
	id integer primary key IDENTITY(1,1),
	sedeid integer not null,
	nombre varchar(512) not null default 'Sin Nombre',
	capacidad integer not null default 0,
	foreign key (sedeid)
	references Sede(Id));



--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Docente
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Docente (
	id integer primary key IDENTITY(1,1),
	personaid integer not null,
	institucionid integer not null,
	fingreso date not null,
	fegreso date,
	foreign key (personaid)
	references Persona(id),
	foreign key (institucionid)
	references Institucion(id));



--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla RelacionParental
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table RelacionParental (
	id integer primary key IDENTITY(1,1),
	autoridadparentalid int not null,
	padreid integer not null check (padreid != hijoid),
	hijoid integer not null check(hijoid != padreid),
	foreign key (padreid)
	references Persona(id),
	foreign key (hijoid)
	references Persona(id),
	foreign key (autoridadparentalid)
	references AutoridadParental(id));

create unique index uix_RelacionParental
on RelacionParental(padreid,hijoid);

create index ix_RelacionParental
on RelacionParental(autoridadparentalid);
-- Cuando haga un join para buscar todos los
-- padres/madres/etc de un curso.

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla ResponsableLegal
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table ResponsableLegal  (
	id integer primary key IDENTITY(1,1),
	personaid integer not null,
	fingreso date not null,
	fegreso date,
	foreign key (personaid)
	references Persona(id));

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Turno
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Turno (
	id integer primary key IDENTITY(1,1),
	institucionorientacionid integer not null,
	sedeid integer not null,
	nombre varchar(512) not null,
	horaentrada varchar(5) not null
	check(strftime('%H:%M',horaentrada) < strftime('%H:%M',horasalida)),
	horasalida varchar(5) not null
	check(strftime('%H:%M',horasalida) > strftime('%H:%M',horaentrada)),
	foreign key (sedeid)
	references Sede(id),
	foreign key (institucionorientacionid)
	references InstitucionOrientacion(id));

create unique index uix_turno
on Turno(institucionorientacionid,sedeid,nombre);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla HorasTurno
----- Orden de la Tabla 007
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table HorasTurno (
	id integer primary key IDENTITY(1,1),
	turnoid integer not null,
	horainicio datetime check(strftime('%H:%M', horainicio) < strftime('%H:%M', horafin)),
	horafin datetime check(strftime('%H:%M', horafin) > strftime('%H:%M', horainicio)));

create unique index uix_horas_turno 
on HorasTurno(turnoid, strftime('%H:%M', horainicio), strftime('%H:%M', horafin));

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla MateriasDocente
----- Orden de la Tabla 007
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table MateriasDocente (
	id integer primary key not null,
	docenteid integer not null,
	materiaid integer not null,
	foreign key (docenteid)
	references Docente(id),
	foreign key (materiaid)
	references Materia(id));

create unique index uix_materia_docente
on MateriasDocente(docenteid,materiaid);

--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla ResponsableLegalAlumno
----- Orden de la Tabla 007
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table ResponsableLegalAlumno (
    id integer primary key IDENTITY(1,1),
    ResponsableLegalid integer not null,
    alumnoid integer not null,
    foreign key (ResponsableLegalid)
    references ResponsableLegal(id),
    foreign key (alumnoid)
    references Alumno(id));

create unique index uix_resp_alumno
on ResponsableLegalAlumno(ResponsableLegalid, alumnoid);
--------------------------------------------
--------------------------------------------
----- Creacion de la Tabla Clase
----- Orden de la Tabla 008
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Clase (
    id integer primary key IDENTITY(1,1),
    comisionid integer not null,
    docenteid integer not null,
    materiaid integer not null,
    aulaid integer not null,
    foreign key (aulaid)
    references Aula(id),
    foreign key (comisionid)
    references Comision(id),
    foreign key (docenteid)
    references Docente(id),
    foreign key (materiaid)
    references Materia(id));

create unique index uix_clase
on Clase(comisionid, aulaid, docenteid, materiaid);

--------------------------------------------
