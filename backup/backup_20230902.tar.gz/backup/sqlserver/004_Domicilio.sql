--------------------------------------------
----- Creacion de la Tabla Domicilio
----- Orden de la Tabla 004
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Domicilio (
	id integer primary key IDENTITY(1,1),
	localidadid integer not null,
	direccion varchar(2048) not null,
	codpos varchar(32),
	foreign key (localidadid)
	references Localidad(id));

--------------------------------------------
