--------------------------------------------
----- Creacion de la Tabla PlanEstudios
----- Orden de la Tabla 003
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table PlanEstudios(
	id integer primary key IDENTITY(1,1),
	InstitucionOrientacionId integer not null,
	nombre varchar(1024) not null,
	fechainicio date,
	fechafin date,
	foreign key (InstitucionOrientacionId)
	references InstitucionOrientacion(id));

create unique index uix_PlanEstudios_InstOrient_nombre
on PlanEstudios(InstitucionOrientacionId,nombre);


--------------------------------------------
