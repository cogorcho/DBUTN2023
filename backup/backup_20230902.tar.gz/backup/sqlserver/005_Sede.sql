--------------------------------------------
----- Creacion de la Tabla Sede
----- Orden de la Tabla 005
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Sede (
	id integer primary key IDENTITY(1,1),
	institucionid integer not null,
	nombre varchar(1024) null,
	domicilioid integer not null,
	foreign key (domicilioid)
	references Domicilio(id),
	foreign key (institucionid)
	references Institucion(id));	

create unique index uix_sede_institucion_nombre
on Sede(institucionid,nombre);

--------------------------------------------
