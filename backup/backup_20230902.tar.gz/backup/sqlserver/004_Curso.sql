--------------------------------------------
----- Creacion de la Tabla Curso
----- Orden de la Tabla 004
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
-- de cada plan-nivel(1rio, 2rio etc)
-- aca va 1er año, 2do grado, etc etc
create table Curso (
	id integer primary key IDENTITY(1,1),
	planestudioid integer not null,
	nivelid integer not null,
	nombre varchar(1024) not null,
	foreign key (planestudioid)
	references PlanEstudios(id),
	foreign key (nivelid)
	references Nivel(id));

create unique index uix_curso_plan_nivel
on Curso(planestudioid,nivelid);

--------------------------------------------
