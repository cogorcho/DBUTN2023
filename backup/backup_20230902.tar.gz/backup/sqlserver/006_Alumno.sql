--------------------------------------------
----- Creacion de la Tabla Alumno
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Alumno  (
	id integer primary key IDENTITY(1,1),
	institucionid integer not null,
	personaid integer not null,
	fingreso date not null,
	fegreso date,
	foreign key (institucionid)
	references Institucion(id),
	foreign key (personaid)
	references Persona(id));

create unique index uix_alumno
on Alumno(institucionid,personaid);

--------------------------------------------
