--------------------------------------------
----- Creacion de la Tabla Provincia
----- Orden de la Tabla 002
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Provincia (
	id integer primary key IDENTITY(1,1),
	paisid integer not null,
	nombre varchar(1024) null,
	foreign key (paisid)
	references Pais(id));	

create unique index uix_pais_provincia_nombre
on Provincia(paisid,nombre);

--------------------------------------------
