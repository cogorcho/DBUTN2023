--------------------------------------------
----- Creacion de la Tabla Aula
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Aula(
	id integer primary key IDENTITY(1,1),
	sedeid integer not null,
	nombre varchar(512) not null default 'Sin Nombre',
	capacidad integer not null default 0,
	foreign key (sedeid)
	references Sede(Id));



--------------------------------------------
