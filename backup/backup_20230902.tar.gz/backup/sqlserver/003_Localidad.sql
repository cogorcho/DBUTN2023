--------------------------------------------
----- Creacion de la Tabla Localidad
----- Orden de la Tabla 003
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table Localidad (
	id integer primary key IDENTITY(1,1),
	provinciaid integer not null,
	nombre varchar(1024) null,
	foreign key (provinciaid)
	references Provincia(id));	

create unique index uix_Localidad_Provincia_nombre
on Localidad(provinciaid,nombre);

--------------------------------------------
