--------------------------------------------
----- Creacion de la Tabla RelacionParental
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table RelacionParental (
	id integer primary key IDENTITY(1,1),
	autoridadparentalid int not null,
	padreid integer not null check (padreid != hijoid),
	hijoid integer not null check(hijoid != padreid),
	foreign key (padreid)
	references Persona(id),
	foreign key (hijoid)
	references Persona(id),
	foreign key (autoridadparentalid)
	references AutoridadParental(id));

create unique index uix_RelacionParental
on RelacionParental(padreid,hijoid);

create index ix_RelacionParental
on RelacionParental(autoridadparentalid);
-- Cuando haga un join para buscar todos los
-- padres/madres/etc de un curso.

--------------------------------------------
