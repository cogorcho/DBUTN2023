--------------------------------------------
----- Creacion de la Tabla AlumnosComision
----- Orden de la Tabla 006
----- Fecha: Sat Sep  2 07:33:11 AM -03 2023 
--------------------------------------------
create table AlumnosComision (
	id integer primary key IDENTITY(1,1),
	comisionid integer not null,
	alumnoid integer not null,
	foreign key (comisionid)
	references Comision(id),
	foreign key (alumnoid)
	references Alumno(id));

create unique index uix_alumnos_comision
on AlumnosComision(comisionid, alumnoid);

--------------------------------------------
