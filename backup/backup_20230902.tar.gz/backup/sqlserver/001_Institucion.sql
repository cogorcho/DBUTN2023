--------------------------------------------
----- Creacion de la Tabla Institucion
----- Orden de la Tabla 001
----- Fecha: Sat Sep  2 07:33:10 AM -03 2023 
--------------------------------------------
create table Institucion (
	id integer primary key IDENTITY(1,1),
	nombre varchar(1024) not null,
	diegrep varchar(512));

create unique index uix_institucion_nombre
on Institucion(nombre);

--------------------------------------------
